var expect = require("chai").expect;
var calculateTax = require("../tax");

// Write tests for the calculateTax function here
