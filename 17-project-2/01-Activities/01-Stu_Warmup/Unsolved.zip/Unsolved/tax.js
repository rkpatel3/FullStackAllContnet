var calculateTax = function(price) {
  // Fill in code here
};

module.exports = calculateTax;
